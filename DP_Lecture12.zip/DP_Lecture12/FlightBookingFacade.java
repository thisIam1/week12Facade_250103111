package DP_Lecture12;
public class FlightBookingFacade {                    // facade class
    // Encapsulated subsystem references
    private final SeatInventorySystem seatSystem;
    private final BaggagePricingEngine baggageEngine;
    private final CurrencyConverter currencyConverter;
    private final PaymentProcessor paymentProcessor;
    private final TicketIssuer ticketIssuer;
    public FlightBookingFacade(){
        this.seatSystem = new SeatInventorySystem();
        this.baggageEngine = new BaggagePricingEngine();
        this.currencyConverter = new CurrencyConverter();
        this.paymentProcessor = new PaymentProcessor();
        this.ticketIssuer = new TicketIssuer();
    }
    public String bookFlight(String passengerName, String flightCode, String seatNumber,
                             double baseFareUSD, int bagCount, double bagWeightKg,
                             String currency, String cardNumber) {
        return bookFlight(passengerName, flightCode, seatNumber, baseFareUSD,
                bagCount, bagWeightKg, currency, cardNumber, "STANDARD");
    }
    /**
     * Single entry point for booking a complete flight itinerary.
     * Coordinates seat locking, baggage pricing, currency conversion,
     * payment execution, rollback on failure, and ticket issuance.
     */
    public String bookFlight(String passengerName, String flightCode, String seatNumber,
                             double baseFareUSD, int bagCount, double bagWeightKg,
                             String currency, String cardNumber, String loyaltyTier) {
        String lockToken = null;
        try {
            seatSystem.connectToReservationServer();  // its todo1
            lockToken = seatSystem.lockSeat(flightCode, seatNumber, passengerName);
            double baggageFee = 0.0;
            if (!loyaltyTier.equals("SILVER") && !loyaltyTier.equals("GOLD")) {
                baggageFee = baggageEngine.calculateBaggageFeeUSD(bagCount, bagWeightKg);
            }
            double totalUSD = baseFareUSD + baggageFee; // its todo2
            double convertedTotal = currencyConverter.convertFromUSD(totalUSD, currency); // its todo3
            paymentProcessor.initializeGateway(); // its todo4
            if (loyaltyTier.equals("SILVER")) {
                paymentProcessor.applyPromoCode("SILVER-FREE-BAG");
            }
            String receiptId = paymentProcessor.chargeCard(cardNumber, convertedTotal, currency); // its todo5(generate)
            return ticketIssuer.generateTicket(passengerName, flightCode, lockToken, receiptId); //todo5(return)
        }catch(RuntimeException ex){
            if(lockToken != null){
                seatSystem.releaseSeatLock(lockToken);  //todo6
            }
            System.out.println("Booking failed: " + ex.getMessage());
            return "BOOKING FAILED;  " + ex.getMessage();
        } finally {
            seatSystem.disconnect(); //disconnecting, itss todo7
        }
    }
}